# CODSOFTJUNE-Intern-Saswati-Word-Count-Task-2
WORD COUNTER


https://github.com/SASWATIMATHAN/CODSOFTJUNE-Intern-Saswati-Word-Count-Task-2/assets/142345833/0a078cf2-7737-4f2f-9352-39b45c84b1e2

